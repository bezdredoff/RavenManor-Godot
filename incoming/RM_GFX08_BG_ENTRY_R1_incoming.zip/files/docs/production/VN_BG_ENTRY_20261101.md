# BG-ENTRY incoming package

This package adds four Entry-family VN backgrounds for Raven Manor:

- BG-ENTRY:day:approachable
- BG-ENTRY:dusk:approachable
- BG-ENTRY:day:overgrown
- BG-ENTRY:dusk:overgrown

## Story-critical mappings
- RM-BEAT-00-03 -> BG-ENTRY:dusk:overgrown
- RM-BEAT-02-02 -> BG-ENTRY:day:approachable

## Files
- 4 WebP backgrounds in assets/raven/vn_backgrounds/entry/
- updated vn_background_catalog.json (14 -> 18 entries)
- updated vn_background_gallery_smoke.gd
- updated vn_runtime_background_smoke.gd

## Asset hashes
- dusk_approachable.webp: 727db24acd782bc3e73798439c4b2513899a2fe9d107de76b2b79b3ba646c4af\n- day_approachable.webp: 4e97252d73f71b5bae00f9adc36b43374ccf9fb60098516a1afa8af32f89112c\n- dusk_overgrown.webp: fd7d28661c069037d5ac22576152846d9ab2ec57072daf252e7773ae9bfab8c8\n- day_overgrown.webp: 192dff481ade54600c24456226daaef66da99e0936277144cea6535bbac34cb0\n
Note: the package manifest uses the last verified main SHA available in this session. If the incoming importer rejects the ZIP due to a baseSha mismatch after new merges, regenerate against the current main SHA.
